package zepeda.cristal.criminalintent
import java.util.*
import java.util.Date
import java.util.UUID
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Crime(
    @PrimaryKey val  id: UUID,
    val title : String,
    val date:Date,
    val isSolved: Boolean,
    val suspect: String ="",
    val photoFileName: String? = null


)
